package com.sakura.autodrama

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { DashboardScreen() } }
    }
}

private val themes = listOf("Romantis", "Komedi", "Sekolah", "Misteri", "Persahabatan")
private val durations = listOf(30, 45, 60)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen() {
    val context = LocalContext.current
    var theme by remember { mutableStateOf(themes[0]) }
    var language by remember { mutableStateOf("Indonesia") }
    var duration by remember { mutableStateOf(60) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Siap. Impor video gameplay untuk memulai.") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            // Simpan izin baca agar video tetap bisa dibuka nanti (tanpa menyalin file besar).
            context.contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            videoUri = uri
            status = "Video diimpor: ${videoName(context, uri)}"
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Sakura Auto Drama AI") }) }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Dashboard (Versi 1)", style = MaterialTheme.typography.titleMedium)

            Text("Tema cerita")
            ChipRow(themes, theme) { theme = it }

            Text("Bahasa")
            ChipRow(listOf("Indonesia", "Inggris"), language) { language = it }

            Text("Durasi (detik)")
            ChipRow(durations.map { it.toString() }, duration.toString()) { duration = it.toInt() }

            Button(
                onClick = { picker.launch(arrayOf("video/*")) },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text("IMPOR VIDEO GAMEPLAY") }

            // Tombol ini sengaja nonaktif sampai Versi 6, supaya tidak jadi "tombol palsu".
            Button(
                onClick = {},
                enabled = false,
                modifier = Modifier.fillMaxWidth().height(72.dp)
            ) { Text("START FULL AUTO DRAMA (tersedia di Versi 6)") }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {}, enabled = false) { Text("PAUSE") }
                OutlinedButton(onClick = {}, enabled = false) { Text("STOP") }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Status", style = MaterialTheme.typography.labelLarge)
                    Text(status)
                    Spacer(Modifier.height(8.dp))
                    Text("Tema: $theme  |  Bahasa: $language  |  Durasi: $duration dtk")
                }
            }

            videoUri?.let { VideoPreview(it) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(o) })
        }
    }
}

@Composable
private fun VideoPreview(uri: Uri) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().height(360.dp)
    )
}

private fun videoName(context: Context, uri: Uri): String =
    context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: uri.lastPathSegment.orEmpty()
